#include <gtk/gtk.h>


void on_butajouter_clicked (GtkButton  *button, gpointer  user_data);
void on_but1modifier_clicked(GtkButton *button, gpointer user_data);
void on_butsupprimer_clicked (GtkButton *button, gpointer user_data);
void on_butajouteragent_clicked(GtkButton *button, gpointer user_data);
void on_buttafficher_clicked (GtkButton *button,gpointer user_data);
void on_butaffecter__clicked (GtkButton  *button,gpointer user_data);
void on_butaffecter_clicked (GtkWidget *objet, gpointer user_data);
void on_buttonajoutprecedent_clicked(GtkButton *button, gpointer user_data);
void on_buttonmodifprecedent_clicked(GtkButton *button,gpointer user_data);
void on_buttonaffichageprecent_clicked (GtkButton *button,gpointer user_data);
void on_buttongereraffectationprecedent__clicked(GtkButton *button, gpointer user_data);
void on_buttonajouterparking_clicked (GtkButton       *button,
                                        gpointer         user_data);
void
on_buttonsupprimerprecedent_clicked    (GtkButton       *button,
                                        gpointer         user_data);
void
on_buttonmodifierparking_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsupprimerparking_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficherparking_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button43_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongereraffectation__clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongereraffectationafficher_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongereraffecterunagent__clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongereraffecterunagent__clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficher2_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffichagajouter_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffichagemodif_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffichagesupprimer_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaaficherajout__clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficheraffectationsupprimr_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficheraffectationmodifier__clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_affecterprecedent__clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


void
on_button44_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonadministrateur_clicked        (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonnouveaucitoyen_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonparking_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_button_add_citoyen_clicked          (GtkButton       *button,
                                        gpointer         user_data);


void
on_del_citoyen_clicked                  (GtkButton       *button,
                                        gpointer         user_data);


void
on_boutton_afficher_citoyen_clicked    (GtkButton       *button,
                                        gpointer         user_data);



void
on_button_supprimer_espace_citoyen_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);



void
on_button_modifier_espace_citoyen_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_home_ajout_client_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_home_supprimer_citoyen_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_home_afficher_citoyen_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_home_calculer_facture_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_home_modifier_citoyen_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_espace_calculer_facture_clicked     (GtkButton       *button,
                                        gpointer         user_data);


void
on_saveupdate_clicked                  (GtkButton       *button,
                                        gpointer         user_data);


void
on_button_login_citoyen_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonanciencitoyen_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_login_citoyen_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_init_clicked                 (GtkButton       *button,
                                        gpointer         user_data);


void
on_deconect_espace_citoyen_clicked     (GtkButton       *button,
                                        gpointer         user_data);


void
on_cnx_loginadmin_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_admin_init_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_ladmincitoyen_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_ajout_citoyen_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_dcnx_du_calcul_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_ladmincitoyen_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_deconect_espace_citoyen_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_ajout_citoyen_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_cnx_loginadmin_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_admin_init_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_dcnx_du_calcul_clicked              (GtkButton       *button,
                                        gpointer         user_data);
void
on_Affiche_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
void
on_deconect_facture_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_login_citoyen_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_init_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button45_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
void
on_affiche_fact_clicked                (GtkButton       *button,
                                        gpointer         user_data);
void
on_boutton_calculer_fact_clicked       (GtkButton       *button,
                                        gpointer         user_data);

