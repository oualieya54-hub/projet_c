#include <gtk/gtk.h>
#include "interface.h"
#include "support.h"

int main(int argc, char *argv[])
{
    GtkWidget *inscrit_cour;
    
    gtk_init(&argc, &argv);
    
    printf("Création de la fenêtre d'inscription...\n");
    
    inscrit_cour = create_inscrit_cour();
    
    if (inscrit_cour == NULL) {
        printf("ERREUR: Impossible de créer la fenêtre!\n");
        return 1;
    }
    
    printf("Fenêtre créée avec succès!\n");
    
    // Afficher la fenêtre
    gtk_widget_show_all(inscrit_cour);
    
    // Quitter quand on ferme la fenêtre
    g_signal_connect(inscrit_cour, "destroy", G_CALLBACK(gtk_main_quit), NULL);
    
    printf("Lancement de l'interface...\n");
    gtk_main();
    
    return 0;
}
