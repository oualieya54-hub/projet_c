#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <gtk/gtk.h>
#include "interface.h"
#include "support.h"
#include "callbacks.h"

int main (int argc, char *argv[])
{
  GtkWidget *cour_sportif_acceuil;
  GtkWidget *inscrit_cour;  // Fenêtre d'inscription
  
#ifdef ENABLE_NLS
  bindtextdomain (GETTEXT_PACKAGE, PACKAGE_LOCALE_DIR);
  bind_textdomain_codeset (GETTEXT_PACKAGE, "UTF-8");
  textdomain (GETTEXT_PACKAGE);
#endif
  
  gtk_set_locale ();
  gtk_init (&argc, &argv);
  
  // Create main window
  printf("Creating main window...\n");
  cour_sportif_acceuil = create_cour_sportif_acceuil();
  
  if (cour_sportif_acceuil == NULL) {
      printf("ERROR: Failed to create main window!\n");
      return 1;
  }
  
  printf("Main window created successfully\n");
  
  // INITIALIZE THE TREEVIEW
  printf("Looking up treeview1...\n");
  GtkWidget *treeview = lookup_widget(cour_sportif_acceuil, "treeview1");
  
  if (treeview != NULL) {
      printf("Initializing treeview with data...\n");
      afficher_cours_treeview(treeview);
      printf("Treeview initialized!\n");
  }
  
  // Create and show inscription window (GTK+2 style)
  printf("Creating inscription window...\n");
  inscrit_cour = create_inscrit_cour();
  
  if (inscrit_cour != NULL) {
      printf("Inscription window created successfully\n");
      gtk_widget_show_all(cour_sportif_acceuil);
  } else {
      printf("ERROR: Failed to create inscription window!\n");
  }
  
  printf("Application started successfully\n");
  gtk_main();
  
  return 0;
}
