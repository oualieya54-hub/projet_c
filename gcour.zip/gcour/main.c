#include <stdio.h>
#include <string.h>
#include "gcour.h"
#include <gtk/gtk.h>

GtkBuilder *builder = NULL;

int main(int argc, char *argv[])
{
    gtk_init(&argc, &argv);

    
    Cours c1 = {"C001", "Yoga", 10, 11, 2025, 8.30, "Fitness", 20, 1};
    Cours c2 = {"C002", "Boxe", 12, 11, 2025, 18.00, "Combat", 15, 0};

    ajouter_cours(c1);
    ajouter_cours(c2);

    afficher_cours();

    Cours r = chercher_cours("C001");
    if (strcmp(r.id, "") != 0)
        printf("\nCours trouvé : %s - %s\n", r.id, r.nom);

    c2.nb_personnes_max = 25;
    modifier_cours(c2);

    supprimer_cours("C001");

    printf("\nAprès modification et suppression:\n");
    afficher_cours();

   
    Inscription I = {"M003", "Nour", "C001", "Yoga", 12, 11, 2025};
    ajouter_inscription(I);
    afficher_inscriptions();

    builder = gtk_builder_new();
gtk_builder_add_from_file(builder, "gestion-cour1.glade", NULL);

gtk_builder_connect_signals(builder, NULL);

GtkWidget *window = GTK_WIDGET(gtk_builder_get_object(builder, "cour_sportif_accueil"));
gtk_widget_show_all(window);	

gtk_main();

    return 0;
}

